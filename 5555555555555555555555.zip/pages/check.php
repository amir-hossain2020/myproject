<?php

require_once("connect.php");

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$email = $_POST['email'];
$id = $_POST['id'];
$password = $_POST['password'];



echo($email);

?>